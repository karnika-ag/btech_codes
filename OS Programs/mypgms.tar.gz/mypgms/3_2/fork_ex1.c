#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
  int i;
   printf("i m another pgm\n");
}
