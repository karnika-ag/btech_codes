#include<iostream>
using namespace std;
int main()
{
int i=8;
if(i==8)cout<<"hello i m 8\n";
else if(i<10)cout<<"in second stmt\n";
else cout<<"end\n";
}
